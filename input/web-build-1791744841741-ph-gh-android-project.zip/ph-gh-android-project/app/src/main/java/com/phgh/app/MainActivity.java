package com.phgh.app;

import android.app.Activity;
import android.app.AlertDialog;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.animation.AccelerateDecelerateInterpolator;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.content.Intent;
import android.net.Uri;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {
    private static final String HOME_URL = "https://ph-gh.com/";
    private static final int NAVY = Color.rgb(16, 24, 39);
    private static final int NAVY_LIGHT = Color.rgb(30, 41, 59);
    private static final int AMBER = Color.rgb(245, 158, 11);
    private WebView webView;
    private FrameLayout root;
    private View splash;
    private boolean pageLoaded = false;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(NAVY);
        getWindow().setNavigationBarColor(NAVY);
        buildInterface();
        showSplash();
        loadHome();
    }

    private void buildInterface() {
        root = new FrameLayout(this);
        root.setBackgroundColor(Color.WHITE);
        LinearLayout shell = new LinearLayout(this);
        shell.setOrientation(LinearLayout.VERTICAL);
        shell.setBackgroundColor(Color.WHITE);

        LinearLayout header = new LinearLayout(this);
        header.setGravity(Gravity.CENTER_VERTICAL);
        header.setPadding(dp(18), dp(8), dp(12), dp(8));
        header.setBackgroundColor(NAVY);
        TextView title = new TextView(this);
        title.setText("●  ph-gh.com");
        title.setTextColor(Color.WHITE);
        title.setTextSize(18);
        title.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        header.addView(title, new LinearLayout.LayoutParams(0, dp(44), 1));
        Button refreshTop = makeButton("↻", true);
        refreshTop.setContentDescription("تازه‌سازی");
        header.addView(refreshTop, new LinearLayout.LayoutParams(dp(48), dp(44)));
        shell.addView(header, new LinearLayout.LayoutParams(-1, dp(60)));

        FrameLayout webHolder = new FrameLayout(this);
        webView = new WebView(this);
        webView.setBackgroundColor(Color.WHITE);
        webView.getSettings().setJavaScriptEnabled(true);
        webView.getSettings().setDomStorageEnabled(true);
        webView.getSettings().setLoadWithOverviewMode(true);
        webView.getSettings().setUseWideViewPort(true);
        webView.getSettings().setMediaPlaybackRequiresUserGesture(false);
        webView.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                String scheme = uri.getScheme();
                if (scheme != null && (scheme.equals("http") || scheme.equals("https"))) return false;
                try { startActivity(new Intent(Intent.ACTION_VIEW, uri)); } catch (Exception ignored) { }
                return true;
            }
            @Override public void onPageFinished(WebView view, String url) {
                pageLoaded = true;
                hideSplash();
            }
        });
        webView.setWebChromeClient(new WebChromeClient() {
            @Override public void onProgressChanged(WebView view, int progress) {
                if (progress >= 100) { pageLoaded = true; hideSplash(); }
            }
        });
        webHolder.addView(webView, new FrameLayout.LayoutParams(-1, -1));
        shell.addView(webHolder, new LinearLayout.LayoutParams(-1, 0, 1));

        LinearLayout nav = new LinearLayout(this);
        nav.setOrientation(LinearLayout.HORIZONTAL);
        nav.setGravity(Gravity.CENTER);
        nav.setPadding(dp(3), dp(5), dp(3), dp(5));
        nav.setBackgroundColor(NAVY);
        addNav(nav, "⌂", "خانه", () -> loadHome());
        addNav(nav, "‹", "بازگشت", () -> goBack());
        addNav(nav, "↻", "تازه‌سازی", () -> { if (webView != null) webView.reload(); showSplashBriefly(); });
        addNav(nav, "↗", "اشتراک", () -> shareSite());
        addNav(nav, "×", "خروج", () -> confirmExit());
        shell.addView(nav, new LinearLayout.LayoutParams(-1, dp(68)));
        root.addView(shell, new FrameLayout.LayoutParams(-1, -1));
        setContentView(root);
        refreshTop.setOnClickListener(v -> { webView.reload(); showSplashBriefly(); });
    }

    private void addNav(LinearLayout bar, String symbol, String label, Runnable action) {
        LinearLayout item = new LinearLayout(this);
        item.setOrientation(LinearLayout.VERTICAL);
        item.setGravity(Gravity.CENTER);
        TextView icon = new TextView(this);
        icon.setText(symbol);
        icon.setTextColor(AMBER);
        icon.setTextSize(25);
        icon.setGravity(Gravity.CENTER);
        TextView text = new TextView(this);
        text.setText(label);
        text.setTextColor(Color.WHITE);
        text.setTextSize(11);
        text.setGravity(Gravity.CENTER);
        item.addView(icon, new LinearLayout.LayoutParams(-1, dp(34)));
        item.addView(text, new LinearLayout.LayoutParams(-1, dp(20)));
        item.setClickable(true);
        item.setFocusable(true);
        item.setOnClickListener(v -> action.run());
        bar.addView(item, new LinearLayout.LayoutParams(0, -1, 1));
    }

    private Button makeButton(String text, boolean light) {
        Button button = new Button(this);
        button.setText(text);
        button.setTextSize(21);
        button.setTextColor(light ? AMBER : Color.WHITE);
        button.setAllCaps(false);
        button.setPadding(0, 0, 0, 0);
        button.setBackground(tint(NAVY_LIGHT, dp(12)));
        return button;
    }

    private GradientDrawable tint(int color, int radius) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(radius);
        return d;
    }

    private void showSplash() {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setGravity(Gravity.CENTER);
        card.setBackgroundColor(NAVY);
        TextView logo = new TextView(this);
        logo.setText("P");
        logo.setTextColor(AMBER);
        logo.setTextSize(46);
        logo.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        logo.setGravity(Gravity.CENTER);
        logo.setBackground(tint(NAVY_LIGHT, dp(24)));
        card.addView(logo, new LinearLayout.LayoutParams(dp(92), dp(92)));
        TextView name = new TextView(this);
        name.setText("ph-gh.com");
        name.setTextColor(Color.WHITE);
        name.setTextSize(25);
        name.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        name.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams nameParams = new LinearLayout.LayoutParams(-2, dp(54));
        nameParams.topMargin = dp(16);
        card.addView(name, nameParams);
        TextView caption = new TextView(this);
        caption.setText("در حال آماده‌سازی…");
        caption.setTextColor(Color.LTGRAY);
        caption.setTextSize(14);
        caption.setGravity(Gravity.CENTER);
        card.addView(caption, new LinearLayout.LayoutParams(-2, dp(32)));
        splash = card;
        root.addView(splash, new FrameLayout.LayoutParams(-1, -1));
        splash.setAlpha(0f);
        splash.setScaleX(0.96f);
        splash.setScaleY(0.96f);
        splash.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(350).setInterpolator(new AccelerateDecelerateInterpolator()).start();
    }

    private void hideSplash() {
        if (splash == null) return;
        View old = splash;
        splash = null;
        old.animate().alpha(0f).scaleX(1.03f).scaleY(1.03f).setDuration(260).withEndAction(() -> root.removeView(old)).start();
    }

    private void showSplashBriefly() {
        if (splash == null) {
            showSplash();
            if (pageLoaded) root.postDelayed(this::hideSplash, 450);
        }
    }

    private void loadHome() {
        if (webView != null) webView.loadUrl(HOME_URL);
    }

    private void goBack() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else Toast.makeText(this, "صفحه قبلی وجود ندارد", Toast.LENGTH_SHORT).show();
    }

    private void shareSite() {
        Intent send = new Intent(Intent.ACTION_SEND);
        send.setType("text/plain");
        send.putExtra(Intent.EXTRA_TEXT, HOME_URL);
        startActivity(Intent.createChooser(send, "اشتراک‌گذاری سایت"));
    }

    private void confirmExit() {
        new AlertDialog.Builder(this)
            .setTitle("خروج از برنامه؟")
            .setMessage("می‌خواهید از ph-gh.com خارج شوید؟")
            .setNegativeButton("انصراف", (d, w) -> d.dismiss())
            .setPositiveButton("خروج", (d, w) -> finish())
            .show();
    }

    @Override public void onBackPressed() { confirmExit(); }

    private int dp(int value) { return (int) (value * getResources().getDisplayMetrics().density + 0.5f); }
}
